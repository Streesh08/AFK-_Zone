<?php
namespace streesh\afkzone\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use muqsit\invmenu\InvMenu;
use muqsit\invmenu\type\InvMenuTypeIds;
use streesh\afkzone\AFKZone;
use streesh\afkzone\utils\MenuUtils;

class AFKZoneCommand extends Command {
    
    private AFKZone $plugin;
    
    public function __construct(AFKZone $plugin) {
        parent::__construct("afkzone", "Manage AFK Zones");
        $this->setPermission("afkzone.admin");
        $this->plugin = $plugin;
    }
    
    public function execute(CommandSender $sender, string $label, array $args): bool {
        if (!isset($args[0])) {
            $this->sendHelp($sender);
            return true;
        }
        
        switch (strtolower($args[0])) {
            case "credits":
                $this->sendCredits($sender);
                break;
                
            case "help":
                $this->sendHelp($sender);
                break;
                
            case "claim":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cThis command must be used in-game");
                    return false;
                }
                if (!$this->testPermission($sender)) {
                    return false;
                }
                $this->handleClaim($sender);
                break;
                
            case "accept":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cThis command must be used in-game");
                    return false;
                }
                if (!$this->testPermission($sender)) {
                    return false;
                }
                $this->handleAccept($sender);
                break;
                
            case "cancel":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cThis command must be used in-game");
                    return false;
                }
                if (!$this->testPermission($sender)) {
                    return false;
                }
                $this->handleCancel($sender);
                break;
                
            case "removeclaim":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cThis command must be used in-game");
                    return false;
                }
                if (!$this->testPermission($sender)) {
                    return false;
                }
                $this->handleRemoveClaim($sender);
                break;
                
            case "reward":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cThis command must be used in-game");
                    return false;
                }
                if (!$this->testPermission($sender)) {
                    return false;
                }
                if (!isset($args[1]) || strtolower($args[1]) !== "edit") {
                    $sender->sendMessage("§cUsage: /afkzone reward edit");
                    return false;
                }
                $this->openEditMenu($sender);
                break;
                
            case "time":
                if (!$sender instanceof Player) {
                    $sender->sendMessage("§cThis command must be used in-game");
                    return false;
                }
                if (!$this->testPermission($sender)) {
                    return false;
                }
                if (!isset($args[1])) {
                    $sender->sendMessage("§cUsage: /afkzone time <value>\n§7Examples: §a/afkzone time 5m §7(5 minutes)\n§a/afkzone time 1h §7(1 hour)\n§a/afkzone time 30s §7(30 seconds)");
                    return false;
                }
                $this->handleTime($sender, $args[1]);
                break;
                
            default:
                $this->sendHelp($sender);
                break;
        }
        
        return true;
    }
    
    private function sendCredits(CommandSender $sender): void {
        $sender->sendMessage("§e---+-------------------------------------+---\n§b§lAFK_ZONE §r§fPlugin\n\n§aDev: §7.streesh\n§aVersion: §71.0.0\n§aAPI: §75.x.x\n§e---+-------------------------------------+---");
    }
    
    private function sendHelp(CommandSender $sender): void {
        if (!$sender->hasPermission("afkzone.admin")) {
            $sender->sendMessage("§cYou don't have permission to use this command!");
            return;
        }
        
        $sender->sendMessage("§e---+--- §b§lAFK_ZONE §r§e---");
        $sender->sendMessage("§a/afkzone help §7- Show this help message");
        $sender->sendMessage("§a/afkzone credits §7- Show plugin credits");
        $sender->sendMessage("§a/afkzone claim §7- Get selector to create AFK Zone");
        $sender->sendMessage("§a/afkzone accept §7- Accept and create the zone");
        $sender->sendMessage("§a/afkzone cancel §7- Cancel current selection");
        $sender->sendMessage("§a/afkzone removeclaim §7- Remove existing AFK Zone");
        $sender->sendMessage("§a/afkzone reward edit §7- Edit AFK rewards");
        $sender->sendMessage("§a/afkzone time <value> §7- Set AFK time (ex: 5m, 1h, 30s)");
        $sender->sendMessage("§e---+-------------------------------------+---");
    }
    
    private function handleClaim(Player $player): void {
        $zoneManager = $this->plugin->getZoneManager();
        
        $zone = $zoneManager->getZone();
        if ($zone !== null) {
            $player->sendMessage("§cThere is already an AFK Zone claim!\n§7Use §a/afkzone removeclaim §7to remove it first");
            return;
        }
        
        $tempData = $zoneManager->getTempData($player->getName());
        if ($tempData !== null) {
            $player->sendMessage("§cYou are already selecting a zone!\n§7Use §a/afkzone accept §7to confirm or §c/afkzone cancel §7to cancel");
            return;
        }
        
        $selectorListener = $this->plugin->getSelectorListener();
        $selectorListener->stopParticleTask($player->getName());
        
        $zoneManager->startSelection($player->getName());
        
        $item = VanillaItems::DIAMOND_HOE();
        $item->setCustomName("§bAFK Zone Selector");
        $item->setLore([
            "§7Left-click to set first position",
            "§7Right-click to set second position",
            "§7Use /afkzone accept to confirm",
            "§7Use /afkzone cancel to cancel"
        ]);
        
        $item->getNamedTag()->setByte("afkzone_selector", 1);
        
        $handItem = $player->getInventory()->getItemInHand();
        if ($handItem->isNull()) {
            $player->getInventory()->setItemInHand($item);
        } else {
            $player->getInventory()->addItem($item);
        }
        
        $player->sendMessage("§aAFK Zone selection started!");
        $player->sendMessage("§7Use the selector tool to mark positions");
        $player->sendMessage("§7Left-click for first position, right-click for second");
        $player->sendMessage("§7Use §a/afkzone accept §7to create zone");
        $player->sendMessage("§7Use §c/afkzone cancel §7to cancel");
    }
    
    private function handleAccept(Player $player): void {
        $zoneManager = $this->plugin->getZoneManager();
        
        $zone = $zoneManager->getZone();
        if ($zone !== null) {
            $player->sendMessage("§cThere is already an AFK Zone claim!\n§7Use §a/afkzone removeclaim §7to remove it first");
            return;
        }
        
        $tempData = $zoneManager->getTempData($player->getName());
        if ($tempData === null) {
            $player->sendMessage("§cYou are not selecting a zone!\n§7Use §a/afkzone claim §7to start selection");
            return;
        }
        
        if ($tempData['pos1'] === null || $tempData['pos2'] === null) {
            $pos1Status = $tempData['pos1'] ? "§aSet at " . $tempData['pos1']['x'] . ", " . $tempData['pos1']['z'] : "§cNot set";
            $pos2Status = $tempData['pos2'] ? "§aSet at " . $tempData['pos2']['x'] . ", " . $tempData['pos2']['z'] : "§cNot set";
            $player->sendMessage("§cYou need to set both positions first!\n§7Position 1: " . $pos1Status . "\n§7Position 2: " . $pos2Status);
            return;
        }
        
        if ($zoneManager->createZone($player->getName())) {
            $player->sendMessage("§aAFK Zone created successfully!\n§7A floating text entity has been spawned in the center.");
            
            $this->removeSelectorItem($player);
            
            $selectorListener = $this->plugin->getSelectorListener();
            $selectorListener->stopParticleTask($player->getName());
        } else {
            $player->sendMessage("§cError creating AFK Zone!");
        }
    }
    
    private function handleCancel(Player $player): void {
        $zoneManager = $this->plugin->getZoneManager();
        $tempData = $zoneManager->getTempData($player->getName());
        
        if ($tempData === null) {
            $player->sendMessage("§cYou are not selecting a zone!");
            return;
        }
        
        $zoneManager->cancelSelection($player->getName());
        $player->sendMessage("§cAFK Zone selection cancelled!");
        
        $this->removeSelectorItem($player);
        
        $selectorListener = $this->plugin->getSelectorListener();
        $selectorListener->stopParticleTask($player->getName());
    }
    
    private function handleRemoveClaim(Player $player): void {
        $zoneManager = $this->plugin->getZoneManager();
        $zone = $zoneManager->getZone();
        
        if ($zone === null) {
            $player->sendMessage("§cThere is no AFK Zone claim to remove!");
            return;
        }
        
        $zoneManager->removeZone();
        $player->sendMessage("§aAFK Zone claim removed successfully!\n§7The floating text entity has been removed.\n§7You can now create a new claim with §a/afkzone claim");
    }
    
    private function handleTime(Player $player, string $timeString): void {
        $seconds = $this->parseTimeString($timeString);
        
        if ($seconds <= 0) {
            $player->sendMessage("§cInvalid time format!\n§7Examples: §a5m §7(5 minutes), §a1h §7(1 hour), §a30s §7(30 seconds)");
            return;
        }
        
        $this->plugin->getZoneManager()->setAFKTime($seconds);
        
        $formattedTime = $this->formatSeconds($seconds);
        $player->sendMessage("§aAFK time set to " . $formattedTime . " (" . $seconds . " seconds)");
    }
    
    private function parseTimeString(string $timeString): int {
        $timeString = strtolower(trim($timeString));
        $totalSeconds = 0;
        
        $pattern = '/(\d+)([smhd])/';
        preg_match_all($pattern, $timeString, $matches, PREG_SET_ORDER);
        
        if (empty($matches)) {
            return 0;
        }
        
        foreach ($matches as $match) {
            $value = (int)$match[1];
            $unit = $match[2];
            
            switch ($unit) {
                case 's': // seconds
                    $totalSeconds += $value;
                    break;
                case 'm': // minutes
                    $totalSeconds += $value * 60;
                    break;
                case 'h': // hours
                    $totalSeconds += $value * 3600;
                    break;
                case 'd': // days
                    $totalSeconds += $value * 86400;
                    break;
            }
        }
        
        return $totalSeconds;
    }
    
    private function formatSeconds(int $seconds): string {
        if ($seconds < 60) {
            return $seconds . " second" . ($seconds !== 1 ? "s" : "");
        } elseif ($seconds < 3600) {
            $minutes = floor($seconds / 60);
            return $minutes . " minute" . ($minutes !== 1 ? "s" : "");
        } elseif ($seconds < 86400) {
            $hours = floor($seconds / 3600);
            $minutes = floor(($seconds % 3600) / 60);
            
            if ($minutes > 0) {
                return $hours . " hour" . ($hours !== 1 ? "s" : "") . " and " . $minutes . " minute" . ($minutes !== 1 ? "s" : "");
            }
            return $hours . " hour" . ($hours !== 1 ? "s" : "");
        } else {
            $days = floor($seconds / 86400);
            $hours = floor(($seconds % 86400) / 3600);
            
            if ($hours > 0) {
                return $days . " day" . ($days !== 1 ? "s" : "") . " and " . $hours . " hour" . ($hours !== 1 ? "s" : "");
            }
            return $days . " day" . ($days !== 1 ? "s" : "");
        }
    }
    
    private function openEditMenu(Player $player): void {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $menu->setName("§l§eEdit AFK Rewards");
        
        $rewards = $this->plugin->getRewardManager()->getRewards();
        if (!empty($rewards)) {
            $menu->getInventory()->setContents($rewards);
        }
        
        $menu->setInventoryCloseListener(function(Player $player, \pocketmine\inventory\Inventory $inventory): void {
            $items = $inventory->getContents();
            $this->plugin->getRewardManager()->setRewards($items);
            $player->sendMessage("§aAFK rewards updated!");
        });
        
        MenuUtils::sendDelayed($player, $menu, 10);
    }
    
    private function removeSelectorItem(Player $player): void {
        foreach ($player->getInventory()->getContents() as $slot => $invItem) {
            if ($invItem->getNamedTag()->getTag("afkzone_selector")) {
                $player->getInventory()->clear($slot);
                break;
            }
        }
    }
}