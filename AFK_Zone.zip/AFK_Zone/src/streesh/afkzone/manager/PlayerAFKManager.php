<?php
namespace streesh\afkzone\manager;

use pocketmine\player\Player;
use pocketmine\world\particle\FlameParticle;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\sound\XpCollectSound;
use pocketmine\world\sound\NoteInstrument;
use pocketmine\world\sound\NoteSound;
use pocketmine\math\Vector3;
use streesh\afkzone\AFKZone;

class PlayerAFKManager {
    
    private AFKZone $plugin;
    private array $afkPlayers = [];
    private array $playerTimes = [];
    
    public function __construct(AFKZone $plugin) {
        $this->plugin = $plugin;
    }
    
    public function addPlayer(Player $player): void {
        $name = $player->getName();
        $this->afkPlayers[$name] = true;
        $this->playerTimes[$name] = time();
        
        $player->getWorld()->addSound($player->getPosition(), new XpCollectSound());
        $player->sendMessage("§aYou entered the AFK Zone");
        
        $this->spawnEntryParticles($player);
    }
    
    public function removePlayer(Player $player): void {
        $name = $player->getName();
        unset($this->afkPlayers[$name], $this->playerTimes[$name]);
        
        $player->getWorld()->addSound($player->getPosition(), new NoteSound(NoteInstrument::PLING(), 1));
        $player->sendMessage("§cYou left the AFK Zone");
    }
    
    private function spawnEntryParticles(Player $player): void {
        $world = $player->getWorld();
        $pos = $player->getPosition();
        $particle = new HappyVillagerParticle();
        
        for ($i = 0; $i < 15; $i++) {
            $x = $pos->x + mt_rand(-10, 10) / 10;
            $z = $pos->z + mt_rand(-10, 10) / 10;
            $y = $pos->y + mt_rand(0, 20) / 10;
            
            $world->addParticle(new Vector3($x, $y, $z), $particle);
        }
    }
    
    public function getPlayersInZoneCount(): int {
        return count($this->afkPlayers);
    }
    
    public function getPlayersInZone(): array {
        return array_keys($this->afkPlayers);
    }
    
    public function isAFK(Player $player): bool {
        return isset($this->afkPlayers[$player->getName()]);
    }
    
    public function tick(): void {
        foreach ($this->afkPlayers as $name => $_) {
            $player = $this->plugin->getServer()->getPlayerExact($name);
            if (!$player instanceof Player || !$player->isOnline()) {
                unset($this->afkPlayers[$name], $this->playerTimes[$name]);
                continue;
            }
            
            $zoneManager = $this->plugin->getZoneManager();
            if (!$zoneManager->isInZone($player->getPosition(), $player->getWorld()->getFolderName())) {
                $this->removePlayer($player);
                continue;
            }
            
            $currentTime = time();
            $startTime = $this->playerTimes[$name];
            $afkTime = $zoneManager->getAFKTime();
            $timeLeft = $afkTime - ($currentTime - $startTime);
            
            if ($timeLeft <= 0) {
                $this->giveReward($player);
                $this->playerTimes[$name] = $currentTime;
                $timeLeft = $afkTime;
            }
            
            $player->sendTip("§eYou are AFK, reward in §a" . $this->formatTime($timeLeft));
        }
    }
    
    private function giveReward(Player $player): void {
        $reward = $this->plugin->getRewardManager()->getRandomReward();
        if ($reward !== null) {
            $player->getInventory()->addItem($reward);
            $player->sendMessage("§aYou received an AFK reward!");
            $player->getWorld()->addSound($player->getPosition(), new XpCollectSound());
        }
    }
    
    public function cleanup(): void {
        $this->afkPlayers = [];
        $this->playerTimes = [];
    }
    
    private function formatTime(int $seconds): string {
        $minutes = floor($seconds / 60);
        $seconds = $seconds % 60;
        return sprintf("%02d:%02d", $minutes, $seconds);
    }
}