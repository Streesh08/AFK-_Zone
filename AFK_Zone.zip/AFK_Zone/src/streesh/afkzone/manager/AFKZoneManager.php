<?php
namespace streesh\afkzone\manager;

use pocketmine\utils\Config;
use pocketmine\math\Vector3;
use streesh\afkzone\AFKZone;
use streesh\afkzone\entity\AFKZoneEntity;

class AFKZoneManager {
    
    private AFKZone $plugin;
    private Config $zonesConfig;
    private array $zones = [];
    private array $tempData = [];
    
    public function __construct(AFKZone $plugin) {
        $this->plugin = $plugin;
        $this->zonesConfig = new Config($plugin->getDataFolder() . "data/zones.yml", Config::YAML, []);
    }
    
    public function loadZones(): void {
        $this->zones = $this->zonesConfig->getAll();
        if (!empty($this->zones)) {
            $this->spawnZoneEntity();
        }
    }
    
    public function saveZones(): void {
        $this->zonesConfig->setAll($this->zones);
        $this->zonesConfig->save();
    }
    
    public function startSelection(string $playerName): void {
        $this->tempData[$playerName] = [
            'pos1' => null,
            'pos2' => null,
            'world' => null,
            'click_type1' => null
        ];
    }
    
    public function getTempData(string $playerName): ?array {
        return $this->tempData[$playerName] ?? null;
    }
    
    public function setTempPosition(string $playerName, Vector3 $pos, string $world, string $clickType): bool {
        if (!isset($this->tempData[$playerName])) {
            return false;
        }
        
        if ($this->tempData[$playerName]['pos1'] === null) {
            $this->tempData[$playerName]['pos1'] = [
                'x' => (int)$pos->x,
                'y' => (int)$pos->y,
                'z' => (int)$pos->z
            ];
            $this->tempData[$playerName]['world'] = $world;
            $this->tempData[$playerName]['click_type1'] = $clickType;
            return true;
        } else {
            if ($this->tempData[$playerName]['world'] !== $world) {
                return false;
            }
            
            $clickType1 = $this->tempData[$playerName]['click_type1'];
            if ($clickType === $clickType1) {
                return false;
            }
            
            $this->tempData[$playerName]['pos2'] = [
                'x' => (int)$pos->x,
                'y' => (int)$pos->y,
                'z' => (int)$pos->z
            ];
            return true;
        }
    }
    
    public function updateSecondPosition(string $playerName, Vector3 $pos, string $world): bool {
        if (!isset($this->tempData[$playerName])) {
            return false;
        }
        
        if ($this->tempData[$playerName]['pos1'] === null || $this->tempData[$playerName]['world'] !== $world) {
            return false;
        }
        
        $this->tempData[$playerName]['pos2'] = [
            'x' => (int)$pos->x,
            'y' => (int)$pos->y,
            'z' => (int)$pos->z
        ];
        return true;
    }
    
    public function createZone(string $playerName): bool {
        if (!isset($this->tempData[$playerName])) {
            return false;
        }
        
        $data = $this->tempData[$playerName];
        if ($data['pos1'] === null || $data['pos2'] === null) {
            return false;
        }
        
        $minX = (int)min($data['pos1']['x'], $data['pos2']['x']);
        $maxX = (int)max($data['pos1']['x'], $data['pos2']['x']);
        $minZ = (int)min($data['pos1']['z'], $data['pos2']['z']);
        $maxZ = (int)max($data['pos1']['z'], $data['pos2']['z']);
        
        $zoneData = [
            'minX' => $minX,
            'maxX' => $maxX,
            'minZ' => $minZ,
            'maxZ' => $maxZ,
            'world' => $data['world'],
            'yLevel' => (int)$data['pos1']['y']
        ];
        
        $this->zones = $zoneData;
        
        unset($this->tempData[$playerName]);
        $this->saveZones();
        
        $this->spawnZoneEntity();
        return true;
    }
    
    public function removeZone(): bool {
        if (empty($this->zones)) {
            return false;
        }
        
        $this->removeZoneEntity();
        $this->zones = [];
        $this->saveZones();
        return true;
    }
    
    public function cancelSelection(string $playerName): void {
        unset($this->tempData[$playerName]);
    }
    
    public function getZone(): ?array {
        return empty($this->zones) ? null : $this->zones;
    }
    
    public function isInZone(Vector3 $position, string $world): bool {
        if (empty($this->zones) || $this->zones['world'] !== $world) {
            return false;
        }

        $x = $position->getFloorX();
        $z = $position->getFloorZ();

        return $x >= $this->zones['minX'] && $x <= $this->zones['maxX']
            && $z >= $this->zones['minZ'] && $z <= $this->zones['maxZ'];
    }
    
    public function getZoneBounds(): ?array {
        if (empty($this->zones)) {
            return null;
        }
        
        return $this->zones;
    }
    
    public function setAFKTime(int $seconds): void {
        $this->zonesConfig->set("afk_time", $seconds);
        $this->zonesConfig->save();
    }
    
    public function getAFKTime(): int {
        return $this->zonesConfig->get("afk_time", 300);
    }
    
    public function spawnZoneEntity(): void {
        if (empty($this->zones)) {
            return;
        }
        
        $this->removeZoneEntity();
        
        $centerX = ($this->zones['minX'] + $this->zones['maxX']) / 2;
        $centerZ = ($this->zones['minZ'] + $this->zones['maxZ']) / 2;
        
        $worldName = $this->zones['world'];
        $world = $this->plugin->getServer()->getWorldManager()->getWorldByName($worldName);
        
        if ($world === null) {
            $this->plugin->getServer()->getWorldManager()->loadWorld($worldName);
            $world = $this->plugin->getServer()->getWorldManager()->getWorldByName($worldName);
            
            if ($world === null) {
                return;
            }
        }
        
        $yLevel = $this->zones['yLevel'] ?? 68;
        $centerY = $yLevel + 3.0;
        
        $entity = AFKZoneEntity::create($centerX, $centerY, $centerZ, $world);
        if ($entity !== null) {
            $entity->spawnToAll();
        }
    }
    
    private function removeZoneEntity(): void {
        if (empty($this->zones)) {
            return;
        }
        
        $worldName = $this->zones['world'];
        $world = $this->plugin->getServer()->getWorldManager()->getWorldByName($worldName);
        
        if ($world === null) {
            return;
        }
        
        foreach ($world->getEntities() as $entity) {
            if ($entity instanceof AFKZoneEntity) {
                $entity->flagForDespawn();
            }
        }
    }
    
    public function cleanup(): void {
        $this->removeZoneEntity();
    }
}