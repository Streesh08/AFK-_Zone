<?php
namespace streesh\afkzone\manager;

use pocketmine\utils\Config;
use pocketmine\item\Item;
use streesh\afkzone\AFKZone;
use streesh\afkzone\utils\Serialize;

class RewardManager {
    
    private AFKZone $plugin;
    private Config $rewardsConfig;
    private array $rewards = [];
    
    public function __construct(AFKZone $plugin) {
        $this->plugin = $plugin;
        $this->rewardsConfig = new Config($plugin->getDataFolder() . "data/rewards.yml", Config::YAML, []);
    }
    
    public function loadRewards(): void {
        $data = $this->rewardsConfig->getAll();
        $this->rewards = [];
        
        foreach ($data as $serializedItem) {
            try {
                $item = Serialize::deserialize($serializedItem);
                $this->rewards[] = $item;
            } catch (\Exception $e) {}
        }
    }
    
    public function saveRewards(): void {
        $serialized = [];
        foreach ($this->rewards as $item) {
            $serialized[] = Serialize::serialize($item);
        }
        $this->rewardsConfig->setAll($serialized);
        $this->rewardsConfig->save();
    }
    
    public function setRewards(array $items): void {
        $this->rewards = $items;
        $this->saveRewards();
    }
    
    public function getRewards(): array {
        return $this->rewards;
    }
    
    public function getRandomReward(): ?Item {
        if (empty($this->rewards)) {
            return null;
        }
        return clone $this->rewards[array_rand($this->rewards)];
    }
}