<?php
namespace streesh\afkzone\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\player\Player;
use pocketmine\item\VanillaItems;
use streesh\afkzone\AFKZone;

class SelectorListener implements Listener {
    
    private AFKZone $plugin;
    
    public function __construct(AFKZone $plugin) {
        $this->plugin = $plugin;
    }
    
    public function onPlayerInteract(PlayerInteractEvent $event): void {
        $player = $event->getPlayer();
        $item = $event->getItem();
        $block = $event->getBlock();
        
        if (!$item->getNamedTag()->getTag("afkzone_selector")) {
            return;
        }
        
        $event->cancel();
        
        $zoneManager = $this->plugin->getZoneManager();
        $tempData = $zoneManager->getTempData($player->getName());
        
        if ($tempData === null) {
            return;
        }
        
        $world = $player->getWorld()->getFolderName();
        $clickType = $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK ? 'right' : 'left';
        
        if ($zoneManager->setTempPosition($player->getName(), $block->getPosition(), $world, $clickType)) {
            $updatedData = $zoneManager->getTempData($player->getName());
            
            if ($updatedData === null) {
                return;
            }
            
            if ($updatedData['pos1'] !== null && $updatedData['pos2'] === null) {
                $clickTypeName = $clickType === 'right' ? "right" : "left";
                $oppositeClick = $clickType === 'right' ? "left" : "right";
                $player->sendMessage("§aFirst position set with §e$clickTypeName-click §aat: §e" . 
                    $block->getPosition()->getFloorX() . ", " . 
                    $block->getPosition()->getFloorZ() . 
                    "\n§7Now use §e$oppositeClick-click §7to set second position\n§7Use §a/afkzone accept §7to create zone\n§7Use §c/afkzone cancel §7to cancel");
                
            } elseif ($updatedData['pos2'] !== null) {
                $player->sendMessage("§aSecond position set at: §e" . 
                    $block->getPosition()->getFloorX() . ", " . 
                    $block->getPosition()->getFloorZ() . 
                    "\n§7You can adjust by clicking another block with §e" . 
                    ($clickType === 'right' ? 'left' : 'right') . "-click" .
                    "\n§7Use §a/afkzone accept §7to create zone\n§7Use §c/afkzone cancel §7to cancel");
            }
        } else {
            if ($tempData['pos1'] !== null && $tempData['pos2'] === null) {
                $clickType1 = $tempData['click_type1'] ?? 'left';
                $oppositeClick = $clickType1 === 'right' ? 'left' : 'right';
                
                if ($clickType === $clickType1) {
                    $player->sendMessage("§cYou must use §e$oppositeClick-click §cfor the second position!");
                    return;
                }
                
                if ($zoneManager->updateSecondPosition($player->getName(), $block->getPosition(), $world)) {
                    $player->sendMessage("§aSecond position updated at: §e" . 
                        $block->getPosition()->getFloorX() . ", " . 
                        $block->getPosition()->getFloorZ() . 
                        "\n§7You can adjust by clicking another block with §e$oppositeClick-click" .
                        "\n§7Use §a/afkzone accept §7to create zone\n§7Use §c/afkzone cancel §7to cancel");
                }
            } elseif ($tempData['pos2'] !== null) {
                $clickType1 = $tempData['click_type1'] ?? 'left';
                $oppositeClick = $clickType1 === 'right' ? 'left' : 'right';
                
                if ($clickType !== $clickType1) {
                    if ($zoneManager->updateSecondPosition($player->getName(), $block->getPosition(), $world)) {
                        $player->sendMessage("§aSecond position updated at: §e" . 
                            $block->getPosition()->getFloorX() . ", " . 
                            $block->getPosition()->getFloorZ() . 
                            "\n§7You can adjust by clicking another block with §e$oppositeClick-click" .
                            "\n§7Use §a/afkzone accept §7to create zone\n§7Use §c/afkzone cancel §7to cancel");
                    }
                } else {
                    $player->sendMessage("§cYou must use §e$oppositeClick-click §cfor adjusting the second position!");
                }
            }
        }
    }
    
    public function onBlockBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        $item = $player->getInventory()->getItemInHand();
        
        if ($item->getNamedTag()->getTag("afkzone_selector")) {
            $event->cancel();
            
            $zoneManager = $this->plugin->getZoneManager();
            $tempData = $zoneManager->getTempData($player->getName());
            
            if ($tempData === null) {
                return;
            }
            
            $world = $player->getWorld()->getFolderName();
            $clickType = 'left';
            
            if ($zoneManager->setTempPosition($player->getName(), $event->getBlock()->getPosition(), $world, $clickType)) {
                $updatedData = $zoneManager->getTempData($player->getName());
                
                if ($updatedData === null) {
                    return;
                }
                
                if ($updatedData['pos1'] !== null && $updatedData['pos2'] === null) {
                    $player->sendMessage("§aFirst position set with §eleft-click §aat: §e" . 
                        $event->getBlock()->getPosition()->getFloorX() . ", " . 
                        $event->getBlock()->getPosition()->getFloorZ() . 
                        "\n§7Now use §eright-click §7to set second position\n§7Use §a/afkzone accept §7to create zone\n§7Use §c/afkzone cancel §7to cancel");
                    
                } elseif ($updatedData['pos2'] !== null) {
                    $player->sendMessage("§aSecond position set at: §e" . 
                        $event->getBlock()->getPosition()->getFloorX() . ", " . 
                        $event->getBlock()->getPosition()->getFloorZ() . 
                        "\n§7You can adjust by right-clicking another block" .
                        "\n§7Use §a/afkzone accept §7to create zone\n§7Use §c/afkzone cancel §7to cancel");
                }
            } else {
                if ($tempData['pos1'] !== null && $tempData['pos2'] === null) {
                    $clickType1 = $tempData['click_type1'] ?? 'left';
                    
                    if ($clickType1 === 'left') {
                        $player->sendMessage("§cYou must use §eright-click §cfor the second position!");
                        return;
                    }
                    
                    if ($zoneManager->updateSecondPosition($player->getName(), $event->getBlock()->getPosition(), $world)) {
                        $player->sendMessage("§aSecond position updated at: §e" . 
                            $event->getBlock()->getPosition()->getFloorX() . ", " . 
                            $event->getBlock()->getPosition()->getFloorZ() . 
                            "\n§7You can adjust by right-clicking another block" .
                            "\n§7Use §a/afkzone accept §7to create zone\n§7Use §c/afkzone cancel §7to cancel");
                    }
                } elseif ($tempData['pos2'] !== null) {
                    $clickType1 = $tempData['click_type1'] ?? 'left';
                    
                    if ($clickType1 === 'right') {
                        if ($zoneManager->updateSecondPosition($player->getName(), $event->getBlock()->getPosition(), $world)) {
                            $player->sendMessage("§aSecond position updated at: §e" . 
                                $event->getBlock()->getPosition()->getFloorX() . ", " . 
                                $event->getBlock()->getPosition()->getFloorZ() . 
                                "\n§7You can adjust by right-clicking another block" .
                                "\n§7Use §a/afkzone accept §7to create zone\n§7Use §c/afkzone cancel §7to cancel");
                        }
                    } else {
                        $player->sendMessage("§cYou must use §eright-click §cfor adjusting the second position!");
                    }
                }
            }
        }
    }
    
    public function stopParticleTask(string $playerName): void {
        #Void
    }
}