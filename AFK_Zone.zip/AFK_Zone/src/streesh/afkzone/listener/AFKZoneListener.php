<?php
namespace streesh\afkzone\listener;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use streesh\afkzone\AFKZone;

class AFKZoneListener implements Listener {
    
    private AFKZone $plugin;
    
    public function __construct(AFKZone $plugin) {
        $this->plugin = $plugin;
    }
    
    public function onPlayerMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        $from = $event->getFrom();
        $to = $event->getTo();
        
        if ($from->getFloorX() === $to->getFloorX() && 
            $from->getFloorY() === $to->getFloorY() && 
            $from->getFloorZ() === $to->getFloorZ()) {
            return;
        }
        
        $zoneManager = $this->plugin->getZoneManager();
        $playerAFKManager = $this->plugin->getPlayerAFKManager();
        
        $world = $player->getWorld()->getFolderName();
        $wasInZone = $zoneManager->isInZone($from, $world);
        $isInZone = $zoneManager->isInZone($to, $world);
        
        if ($isInZone && !$wasInZone && !$playerAFKManager->isAFK($player)) {
            $playerAFKManager->addPlayer($player);
        } elseif (!$isInZone && $wasInZone && $playerAFKManager->isAFK($player)) {
            $playerAFKManager->removePlayer($player);
        }
    }
    
    public function onPlayerQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $this->plugin->getPlayerAFKManager()->removePlayer($player);
    }
}