<?php
namespace streesh\afkzone\entity;

use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\world\World;
use pocketmine\entity\Location;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;

class AFKZoneEntity extends Entity {
    
    public bool $canCollide = false;
    protected bool $immobile = true;
    
    protected function getInitialDragMultiplier(): float{ return 0.00; }
    protected function getInitialGravity(): float{ return 0.00; }
    
    public static function create(float $x, float $y, float $z, World $world): self {
        $nbt = CompoundTag::create()
            ->setTag("Pos", new ListTag([
                new DoubleTag($x),
                new DoubleTag($y),
                new DoubleTag($z)
            ]))
            ->setTag("Motion", new ListTag([
                new DoubleTag(0),
                new DoubleTag(0),
                new DoubleTag(0)
            ]))
            ->setTag("Rotation", new ListTag([
                new FloatTag(0),
                new FloatTag(0)
            ]));
        
        $location = new Location($x, $y, $z, $world, 0, 0);
        $entity = new self($location, $nbt);
        
        // Configurar propiedades inmediatamente
        $entity->setNameTagAlwaysVisible(true);
        $entity->setNameTag("§l§bAFK ZONE§r\n§7Don't leave the server, stay here and receive rewards");
        $entity->setScale(0.001);
        
        return $entity;
    }
    
    public function canBeMovedByCurrents(): bool {
        return false;
    }
    
    public function onUpdate(int $currentTick): bool {
        if ($this->isClosed()) {
            return false;
        }
        
        // Asegurar que el nametag esté visible
        if (!$this->isNameTagAlwaysVisible()) {
            $this->setNameTagAlwaysVisible(true);
        }
        
        return parent::onUpdate($currentTick);
    }
    
    public function attack(EntityDamageEvent $source): void {
        $source->cancel();
    }
    
    public static function getNetworkTypeId(): string {
        return EntityIds::XP_ORB;
    }
    
    protected function getInitialSizeInfo(): EntitySizeInfo {
        return new EntitySizeInfo(0.0, 0.0);
    }
    
    public function canBePushed(): bool {
        return false;
    }
    
    public function canSaveWithChunk(): bool {
        return true;
    }
}