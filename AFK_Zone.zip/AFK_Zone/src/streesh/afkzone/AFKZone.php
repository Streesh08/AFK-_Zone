<?php
namespace streesh\afkzone;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\entity\EntityFactory;
use pocketmine\entity\EntityDataHelper;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\world\World;
use muqsit\invmenu\InvMenuHandler;
use streesh\afkzone\command\AFKZoneCommand;
use streesh\afkzone\listener\AFKZoneListener;
use streesh\afkzone\listener\SelectorListener;
use streesh\afkzone\manager\AFKZoneManager;
use streesh\afkzone\manager\RewardManager;
use streesh\afkzone\manager\PlayerAFKManager;
use streesh\afkzone\entity\AFKZoneEntity;

class AFKZone extends PluginBase {
    
    private static self $instance;
    private AFKZoneManager $zoneManager;
    private RewardManager $rewardManager;
    private PlayerAFKManager $playerAFKManager;
    private SelectorListener $selectorListener;
    
    public function onLoad(): void {
        self::$instance = $this;
        
        EntityFactory::getInstance()->register(AFKZoneEntity::class, function(World $world, CompoundTag $nbt): AFKZoneEntity {
            return new AFKZoneEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt);
        }, ['AFKZoneEntity', 'streesh:afkzone_entity']);
    }
    
    public function onEnable(): void {
        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }
        
        @mkdir($this->getDataFolder() . "data/");
        
        $this->zoneManager = new AFKZoneManager($this);
        $this->rewardManager = new RewardManager($this);
        $this->playerAFKManager = new PlayerAFKManager($this);
        
        $this->selectorListener = new SelectorListener($this);
        
        $this->getServer()->getCommandMap()->register("afkzone", new AFKZoneCommand($this));
        
        $this->getServer()->getPluginManager()->registerEvents(new AFKZoneListener($this), $this);
        $this->getServer()->getPluginManager()->registerEvents($this->selectorListener, $this);
        
        $this->zoneManager->loadZones();
        $this->rewardManager->loadRewards();
        
        $this->getScheduler()->scheduleRepeatingTask(new class($this) extends \pocketmine\scheduler\Task {
            private AFKZone $plugin;
            
            public function __construct(AFKZone $plugin) {
                $this->plugin = $plugin;
            }
            
            public function onRun(): void {
                $this->plugin->getPlayerAFKManager()->tick();
            }
        }, 20);
        
        $this->getLogger()->info("§aAFK_Zone plugin enabled!");
    }
    
    public function onDisable(): void {
        $this->zoneManager->saveZones();
        $this->rewardManager->saveRewards();
        $this->playerAFKManager->cleanup();
        $this->zoneManager->cleanup();
        $this->getLogger()->info("§cAFK_Zone plugin disabled!");
    }
    
    public static function getInstance(): self {
        return self::$instance;
    }
    
    public function getZoneManager(): AFKZoneManager {
        return $this->zoneManager;
    }
    
    public function getRewardManager(): RewardManager {
        return $this->rewardManager;
    }
    
    public function getPlayerAFKManager(): PlayerAFKManager {
        return $this->playerAFKManager;
    }
    
    public function getSelectorListener(): SelectorListener {
        return $this->selectorListener;
    }
}