<?php
declare(strict_types=1);

namespace streesh\afkzone\utils;

use muqsit\invmenu\InvMenu;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use streesh\afkzone\AFKZone;

final class MenuUtils
{
    public static function sendDelayed(Player $player, InvMenu $menu, int $ticks = 20): void
    {
        if (!$player->isOnline()) {
            return;
        }

        AFKZone::getInstance()->getScheduler()->scheduleDelayedTask(
            new ClosureTask(function() use ($player, $menu): void {
                if ($player->isOnline()) {
                    $menu->send($player);
                }
            }),
            $ticks
        );
    }
}